import java.io.*;
import java.util.List;
import java.util.ArrayList;

public class Cliente implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String nomeArquivo = "clientes.dat";
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String BOLD = "\u001B[1m";
    public static final String YELLOW = "\u001B[33m";
    public static final String UNDERLINE = "\u001B[4m";

    private String nomeCompleto;
    private String telefone;

    public Cliente(String nomeCompleto, String telefone) {
        this.nomeCompleto = nomeCompleto;
        this.telefone = telefone;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public String getTelefone() {
        return telefone;
    }

    @Override
    public String toString() {
        return BOLD + "| Nome: " + nomeCompleto + ", Telefone: " + telefone + RESET;
    }

    public static void salvarClientes(List<Cliente> clientes) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            outputStream.writeObject(clientes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Cliente> carregarClientes() {
        List<Cliente> clientes = new ArrayList<>();
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(nomeArquivo))) {
            Object obj = inputStream.readObject();
            if (obj instanceof List) {
                List<?> objList = (List<?>) obj;
                for (Object item : objList) {
                    if (item instanceof Cliente) {
                        clientes.add((Cliente) item);
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return clientes;
    }

    public static void mostrarClientes(List<Cliente> clientes) {
        System.out.println(RED + BOLD +"----------------------------------------------------------" + RESET);
        if (clientes.isEmpty()) {
            System.out.println(UNDERLINE + "Nenhum cliente cadastrado." + RESET);
        } else {
            System.out.println(BOLD + "| Cadastros de clientes:"+ RESET);
            for (Cliente cliente : clientes) {
                System.out.println(cliente);
            }
        }
        System.out.println(RED + BOLD +"----------------------------------------------------------" + RESET);
    }

    public static boolean clienteExiste(List<Cliente> clientes, Cliente cliente) {
        for (Cliente c : clientes) {
            if (c.getTelefone().equals(cliente.getTelefone())) {
                return true;
            }
        }
        return false;
    }

    public static void removerCliente(List<Cliente> clientes, String nome) {
        if (nome == null || nome.isEmpty()) {
            System.out.println(UNDERLINE + "Nome inválido." + RESET);
            return;
        }

        Cliente clienteRemover = null;

        for (Cliente cliente : clientes) {
            String nomeCompleto = cliente.getNomeCompleto();
            if (nomeCompleto != null && nomeCompleto.equals(nome)) {
                clienteRemover = cliente;
                break;
            }
        }

        if (clienteRemover != null) {
            clientes.remove(clienteRemover);
            System.out.println(BOLD + "Cliente removido com sucesso."+ RESET);
        } else {
            System.out.println(UNDERLINE +"Cliente não encontrado."+ RESET);
        }
    }
    
}

