public class Aluguel {
    private Cliente cliente;
    private String tipoVeiculo;
    private String modeloVeiculo;
    private int diasAluguel;
    private double custoTotal;
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String BOLD = "\u001B[1m";
    public static final String YELLOW = "\u001B[33m";
    public static final String UNDERLINE = "\u001B[4m";

    public Aluguel(Cliente cliente, String tipoVeiculo, String modeloVeiculo, int diasAluguel, double custoTotal) {
        this.cliente = cliente;
        this.tipoVeiculo = tipoVeiculo;
        this.modeloVeiculo = modeloVeiculo;
        this.diasAluguel = diasAluguel;
        this.custoTotal = custoTotal;
    }
    

    public Cliente getCliente() {
        return cliente;
    }

    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    public String getModeloVeiculo() {
        return modeloVeiculo;
    }

    public int getDiasAluguel() {
        return diasAluguel;
    }

    public double getCustoTotal() {
        return custoTotal;
    }

    @Override
    public String toString() {
        return BOLD + "| Aluguel [cliente=" + cliente + ", Tipo Veiculo=" + tipoVeiculo + ", Modelo Veiculo=" + modeloVeiculo + ", Dias Aluguel=" + diasAluguel + ", Custo Total=" + custoTotal + "]" + RESET;
    }

    public String getModeloEscolhido() {
        return null;
    }
}
