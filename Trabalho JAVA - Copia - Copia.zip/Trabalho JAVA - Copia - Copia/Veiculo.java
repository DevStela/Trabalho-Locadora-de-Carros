import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Veiculo implements Serializable {
    private String tipo;
    private String nome;
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String BOLD = "\u001B[1m";
    public static final String YELLOW = "\u001B[33m";
    public static final String UNDERLINE = "\u001B[4m";

    public Veiculo(String tipo, String nome) {
        this.tipo = tipo;
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return  BOLD + "| Tipo: " + tipo + ", Nome: " + nome + RESET;
    }

    public static void cadastrarVeiculo(List<Veiculo> veiculos, String tipoVeiculo, String nomeVeiculo) {
        if (!Arrays.asList("SUV", "Hatch", "Sedan").contains(tipoVeiculo)) {
            System.out.println(UNDERLINE +"Tipo de veículo inválido. Escolha entre SUV, Hatch ou Sedan." + RESET);
            return;
        }

        Veiculo veiculo = new Veiculo(tipoVeiculo, nomeVeiculo);
        veiculos.add(veiculo);
        System.out.println(BOLD + "Veículo cadastrado com sucesso." + RESET);
        salvarVeiculosEmArquivo(veiculos);
    }

    public static void mostrarVeiculosCadastrados(List<Veiculo> veiculos) {
        System.out.println(RED + BOLD +"----------------------------------------------------------" + RESET);
        if (veiculos.isEmpty()) {
            System.out.println(UNDERLINE + "Nenhum veículo cadastrado." + RESET);
        } else {
            System.out.println(BOLD + "| Veículos cadastrados:" + RESET);
            for (Veiculo veiculo : veiculos) {
                System.out.println(veiculo);
            }
        }
        System.out.println(RED + BOLD +"----------------------------------------------------------" + RESET);
    }

    public static void removerVeiculo(List<Veiculo> veiculos, String tipo, String nome) {
        Veiculo veiculoRemover = null;
        for (Veiculo veiculo : veiculos) {
            if (veiculo.getTipo().equals(tipo) && veiculo.getNome().equals(nome)) {
                veiculoRemover = veiculo;
                break;
            }
        }

        if (veiculoRemover != null) {
            veiculos.remove(veiculoRemover);
            System.out.println(BOLD +"Veículo removido com sucesso." + RESET);
        } else {
            System.out.println(UNDERLINE +"Veículo não encontrado." + RESET);
        }
    }

    public static void salvarVeiculosEmArquivo(List<Veiculo> veiculos) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("veiculos.dat"))) {
            outputStream.writeObject(veiculos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Veiculo> carregarVeiculosDeArquivo() {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("veiculos.dat"))) {
            return (List<Veiculo>) inputStream.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
