import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LocadoraDeCarros {
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String BOLD = "\u001B[1m";
    public static final String YELLOW = "\u001B[33m";
    public static final String UNDERLINE = "\u001B[4m";
    
    private List<Cliente> clientes;
    List<Veiculo> veiculos;
    private List<Aluguel> alugueis;
    private List<String> clientesComCarrosAlugados;

    public LocadoraDeCarros() {
        this.clientes = new ArrayList<>();
        this.veiculos = new ArrayList<>();
        this.alugueis = new ArrayList<>();
        
        this.clientesComCarrosAlugados = new ArrayList<>(); 


       
        carregarClientesDeArquivo();
        carregarVeiculosDeArquivo();

    }

    public void salvarVeiculosEmArquivo() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("veiculos.dat"))) {
            outputStream.writeObject(veiculos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public void carregarVeiculosDeArquivo() {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("veiculos.dat"))) {
            veiculos = (List<Veiculo>) inputStream.readObject();
        } catch (FileNotFoundException e) {
            veiculos = new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Veiculo> getVeiculos() {
        return veiculos;
    }

    public void salvarClientesEmArquivo() {
        Cliente.salvarClientes(clientes);
    }

    public void carregarClientesDeArquivo() {
        clientes = Cliente.carregarClientes();
    }

    public void cadastrarCliente(String nomeCompleto, String telefone) {
        Cliente cliente = new Cliente(nomeCompleto, telefone);
        if (Cliente.clienteExiste(clientes, cliente)) {
            System.out.println(UNDERLINE + "Este número de telefone já está em uso por outro cliente." + RESET);
            return;
        }

        clientes.add(cliente);
        System.out.println(BOLD + "Cliente cadastrado com sucesso."+ RESET);
        salvarClientesEmArquivo();
    }

    public void verificarCadastros() {
        Cliente.mostrarClientes(clientes);
    }

    public void removerCliente(String nome) {
        Cliente.removerCliente(clientes, nome);
        salvarClientesEmArquivo();
    }

    
    public void alugarVeiculo(String nomeCliente, Scanner scanner) {
        List<Cliente> clientesComMesmoNome = new ArrayList<>();
    
        for (Cliente c : clientes) {
            if (c.getNomeCompleto().equalsIgnoreCase(nomeCliente)) {
                clientesComMesmoNome.add(c);
            }
        }
    
       
    
        if (clientesComMesmoNome.isEmpty()) {
            System.out.println(UNDERLINE + "Cliente não encontrado. Por favor, cadastre-se antes de alugar um veículo."+ RESET);
            return;
        }
    
        Cliente clienteSelecionado = null;
    
        if (clientesComMesmoNome.size() > 1) {
            System.out.println(BOLD + "Vários clientes com o mesmo nome encontrados. Informe o número de telefone para selecionar:" + RESET);
    
            for (int i = 0; i < clientesComMesmoNome.size(); i++) {
                System.out.println((i + 1) + ". " + clientesComMesmoNome.get(i).getTelefone());
            }
    
            System.out.print(BOLD + YELLOW + "Escolha o número de telefone: "+ RESET);
            int escolhaTelefone = scanner.nextInt();
    
            if (escolhaTelefone < 1 || escolhaTelefone > clientesComMesmoNome.size()) {
                System.out.println(UNDERLINE + "Escolha inválida. Reiniciando o processo."+ RESET);
                return;
            }
    
            clienteSelecionado = clientesComMesmoNome.get(escolhaTelefone - 1);
        } else {
            clienteSelecionado = clientesComMesmoNome.get(0);
        }
    
        String telefoneCliente = clienteSelecionado.getTelefone();
        
        if (clientesComCarrosAlugados.contains(telefoneCliente)) {
            System.out.println(UNDERLINE +"Este cliente já tem um carro alugado." + RESET);
            return;
        }
    
        System.out.print(BOLD + YELLOW +"| Escolha o tipo de veículo (SUV, Hatch, Sedan): " + RESET);
        String tipoVeiculo = scanner.next();
        if (!Arrays.asList("SUV", "Hatch", "Sedan").contains(tipoVeiculo)) {
            System.out.println(UNDERLINE +"Tipo de veículo inválido. Reiniciando o processo." + RESET);
            return;
        }
    
        System.out.println("| Modelos disponíveis:");
    
        for (Veiculo veiculo : veiculos) {
            if (veiculo.getTipo().equals(tipoVeiculo)) {
                System.out.println(BOLD + "| " + RESET + veiculo.getNome());
            }
        }
    
        System.out.print(YELLOW + "| Escolha o modelo: " + RESET);
        String modeloEscolhido = scanner.next();
    
        System.out.print(YELLOW + "| Informe a quantidade de dias de aluguel: " + RESET);
        int diasAluguel = scanner.nextInt();
    
        double custoDiario = calcularCustoDiario(tipoVeiculo);
        double custoTotal = custoDiario * diasAluguel;
    
        System.out.println(UNDERLINE +"| Valor do aluguel: R$"+ RESET + custoTotal);
        System.out.print(YELLOW + BOLD +"| Aceita o contrato? (S para Sim, N para Não): "+ RESET);
        String resposta = scanner.next();
    
        if (resposta.equalsIgnoreCase("S")) {
            Veiculo veiculoAlugado = null;
    
            for (Veiculo veiculo : veiculos) {
                if (veiculo.getTipo().equals(tipoVeiculo) && veiculo.getNome().equals(modeloEscolhido)) {
                    veiculoAlugado = veiculo;
                    break;
                }
            }
    
            if (veiculoAlugado == null) {
                System.out.println(UNDERLINE +"Veículo não encontrado. Reiniciando o processo."+ RESET);
                return;
            }
    
            veiculos.remove(veiculoAlugado);
    
            Aluguel aluguel = new Aluguel(clienteSelecionado, tipoVeiculo, modeloEscolhido, diasAluguel, custoTotal);
            alugueis.add(aluguel);
            clientesComCarrosAlugados.add(telefoneCliente); 
            System.out.println("Aluguel realizado com sucesso.");
        } else {
            System.out.println(UNDERLINE + "Aluguel cancelado." + RESET);
        }
    }
    
    
    
        private double calcularCustoDiario(String tipoVeiculo) {
            if (tipoVeiculo.equals(BOLD +"SUV"+ RESET)) {
                return 100.0;
            } else if (tipoVeiculo.equals(BOLD +"Hatch"+ RESET)) {
                return 80.0;
            } else if (tipoVeiculo.equals(BOLD +"Sedan"+ RESET)) {
                return 90.0;
            } else {
                return 0.0;
            }
        }

    public void mostrarAlugueis() {
        if (alugueis.isEmpty()) {
            System.out.println(UNDERLINE + "Nenhum veículo alugado no momento." + RESET);
        } else {
            System.out.println(BOLD + "Veículos alugados:" + RESET);
            for (Aluguel aluguel : alugueis) {
                System.out.println(aluguel);
            }
        }
    }

    public void removerAluguel(String nomeCliente) {
        Aluguel aluguelRemover = null;
        for (Aluguel aluguel : alugueis) {
            if (aluguel.getCliente().getNomeCompleto().equals(nomeCliente)) {
                aluguelRemover = aluguel;
                break;
            }
        }

        if (aluguelRemover != null) {
            alugueis.remove(aluguelRemover);
            System.out.println(BOLD + "Aluguel removido com sucesso."+ RESET);
        } else {
            System.out.println(UNDERLINE +"Nenhum aluguel encontrado para o cliente."+ RESET);
        }
    }


    
    /*public class ColorfulConsole {

        public static final String RESET = "\u001B[0m";
    
        public static final String BLACK = "\u001B[30m";
        public static final String RED = "\u001B[31m";
        public static final String GREEN = "\u001B[32m";
        public static final String YELLOW = "\u001B[33m";
        public static final String BLUE = "\u001B[34m";
        public static final String MAGENTA = "\u001B[35m";
        public static final String CYAN = "\u001B[36m";
        public static final String WHITE = "\u001B[37m";
    
        // Estilos do texto
        public static final String BOLD = "\u001B[1m";
        public static final String UNDERLINE = "\u001B[4m";
        public static final String ITALIC = "\u001B[3m";
        public static final String INVERSE = "\u001B[7m";
    
        public static void main(String[] args) {
            System.out.println(RED + "Texto vermelho" + RESET);
            System.out.println(GREEN + "Texto verde" + RESET);
            System.out.println(BLUE + "Texto azul" + RESET);
            System.out.println(YELLOW + "Texto amarelo" + RESET);
            System.out.println(MAGENTA + "Texto magenta" + RESET);
            System.out.println(CYAN + "Texto cyan" + RESET);
            System.out.println(WHITE + "Texto branco" + RESET);
    
            // Estilos
            System.out.println(BOLD + "Texto em negrito" + RESET);
            System.out.println(UNDERLINE + "Texto sublinhado" + RESET);
            System.out.println(ITALIC + "Texto em itálico" + RESET);
            System.out.println(INVERSE + "Texto invertido" + RESET);
        }
    }*/
    
    
    
}
