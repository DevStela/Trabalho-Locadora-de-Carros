import java.util.Scanner;

public class LocadoraDeCarrosApp {
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String BOLD = "\u001B[1m";
    public static final String YELLOW = "\u001B[33m";
    public static final String UNDERLINE = "\u001B[4m";



    public static void main(String[] args) {

        try (Scanner scanner = new Scanner(System.in)) {
            LocadoraDeCarros locadora = new LocadoraDeCarros();

            locadora.carregarClientesDeArquivo();
            locadora.carregarVeiculosDeArquivo();

            while (true) {
                System.out.println(RED + BOLD +"-------------------------------------------------------------------" + RESET);
                System.out.println(RED + BOLD +"| Seja bem-vindo a LocaBOA, a melhor locadora de carros da região |" + RESET);
                System.out.println(RED + BOLD +"-------------------------------------------------------------------" + RESET);

                System.out.println(BOLD + "| 1. Cadastrar Cliente.");
                System.out.println("| 2. Verificar clientes cadastrados.");
                System.out.println("| 3. Remover cadastro de cliente.");
                System.out.println("| 4. Cadastrar veículo.");
                System.out.println("| 5. Verificar veículos disponíveis.");
                System.out.println("| 6. Remover veículo.");
                System.out.println("| 7. Alugar veículo.");
                System.out.println("| 8. Verificar veículos alugados por clientes.");
                System.out.println("| 9. Remover aluguel.");
                System.out.println("| 10. Finalizar." + RESET);

                System.out.print(YELLOW + "| Opção de escolha (1-9): "+ RESET);
                String escolha = scanner.next();

                switch (escolha) {
                    case "1":
                        scanner.nextLine();
                        System.out.print(YELLOW +"| Informe o nome completo do cliente: "+ RESET);
                        String nomeCompleto = scanner.nextLine();
                        System.out.print(YELLOW +"| Informe o telefone do cliente: "+ RESET);
                        String telefone = scanner.nextLine();
                        locadora.cadastrarCliente(nomeCompleto, telefone);
                        locadora.salvarClientesEmArquivo(); 
                        break;

                    case "2":
                        locadora.verificarCadastros();
                        break;

                    case "3":
                        scanner.nextLine();
                        System.out.print(YELLOW +"| Informe o nome do cliente a ser removido: "+ RESET);
                        String nomeRemover = scanner.nextLine();
                        locadora.removerCliente(nomeRemover);
                        locadora.salvarClientesEmArquivo(); 
                        break;

                    case "4":
                        System.out.print(YELLOW +"| Informe o tipo do veículo (SUV, Hatch, Sedan): "+ RESET);
                        String tipoVeiculo = scanner.next();
                        System.out.print(YELLOW +"| Informe o nome do veículo: "+ RESET);
                        String nomeVeiculo = scanner.next();
                        Veiculo.cadastrarVeiculo(locadora.getVeiculos(), tipoVeiculo, nomeVeiculo);
                        break;
                    
                    case "5":
                        Veiculo.mostrarVeiculosCadastrados(locadora.getVeiculos());
                        break;

                    case "6":
                        scanner.nextLine();
                        System.out.print(YELLOW +"| Informe o tipo do veículo (SUV, Hatch, Sedan): "+ RESET);
                        String tipoVeiculoRemover = scanner.next();
                        System.out.print(YELLOW +"| Informe o nome do veículo a ser removido: "+ RESET);
                        String nomeVeiculoRemover = scanner.next();
                        Veiculo.removerVeiculo(locadora.getVeiculos(), tipoVeiculoRemover, nomeVeiculoRemover);
                        locadora.salvarVeiculosEmArquivo();
                        break;
       
                    case "7":
                        scanner.nextLine();
                    
                        System.out.print(YELLOW +"| Informe o nome do cliente que deseja alugar um veículo: "+ RESET);
                        String clienteAluguel = scanner.nextLine();
                        locadora.alugarVeiculo(clienteAluguel, scanner);
                    
                        break;
                    

                    case "8":
                        locadora.mostrarAlugueis();
                        break;

                    case "9":
                         scanner.nextLine();

                        System.out.print(YELLOW +"| Informe o nome do cliente para remover o aluguel: "+ RESET);
                        String clienteRemoverAluguel = scanner.nextLine();
                        locadora.removerAluguel(clienteRemoverAluguel);
                        break;

                    case "10":
                        
                        System.out.println(RED + BOLD +"| Obrigado por utilizar os serviços da LocaBOA. Volte sempre!"+ RESET);
                        locadora.salvarClientesEmArquivo();
                        locadora.salvarVeiculosEmArquivo();
                        scanner.close();
                        return;

                    default:
                        System.out.println(UNDERLINE + "| Opção inválida. Por favor, escolha uma opção válida." + RESET);
                }
            }
        }
    }
    
    
}
